const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
/*
גישה לאובייקטי הבקשה והתגובה ויכולה לבצע פעולות מסוימות לפני
 העברת הבקשה לתווך הבא או סיום מחזור הבקשה-תגובה.*/
const cors = require('cors');
var path = require('path');

const app = express();
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
/*
gridfs-stream is a package for streaming files to and from MongoDB using GridFS,
which is a specification for storing and retrieving large binary files in MongoDB.
*/
const Grid = require("gridfs-stream");

const upload = require("./routes/upload");

const PORT = process.env.PORT || 5000;

// Connect to DB
mongoose.set('strictQuery', false);
mongoose.connect(
    process.env.MONGO_URL,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    }
)
.then(() => console.log('💾 Connected to DB'))
.catch((err) => {
    console.error(err);
});

const conn = mongoose.connection;
conn.once("open", function () {
    gfs = Grid(conn.db, mongoose.mongo);
    gfs.collection("photos");
});
// Setting EJS as templating engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
// Middleware
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function (req, res) {
    res.redirect('/signin');
});

app.use(require('./routes/signin'));
app.use(require('./routes/signup'));
app.use(require('./routes/signout'));
app.use(require('./routes/dashboard'));
app.use(require('./routes/createExam'));
app.use(require('./routes/editExam'));
app.use(require('./routes/exam'));
app.use(require('./routes/examResult'));
app.use(require('./routes/statistics'));
app.use("/file", upload);

// media routes
app.get("/file/:filename", async (req, res) => {
    try{
        const file = await gfs.files.findOne({ filename: req.params.filename });
        const readStream = gfs.createReadStream(file.filename);
        readStream.pipe(res);
    } catch (error) {
        res.send("not found");
    }
});

app.delete("/file/:filename", async (req, res) => {
    try {
        await gfs.files.deleteOne({ filename: req.params.filename });
        res.send("success");
    } catch (error) {
        console.log(error);
        res.send("An error occured.");
    }
});

app.listen(PORT, () => console.log(`🏎  API Server up and running at localhost:${process.env.PORT}`));