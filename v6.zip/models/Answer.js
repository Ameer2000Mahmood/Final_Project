const mongoose = require("mongoose");

const answerSchema = new mongoose.Schema({
    answer: {
        type: String,
        required: true,//לכל מסמך באוסף חייב להיות ערך עבור מאפיין התשובה
    },
    answerSymbol: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: ['true', 'false'],
        required: true,
    },
    questionId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Question',
    },
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

module.exports = mongoose.model("Answer", answerSchema);
