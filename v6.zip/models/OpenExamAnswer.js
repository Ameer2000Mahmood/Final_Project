const mongoose = require("mongoose");

const openExamAnswerSchema = new mongoose.Schema({
    studentId: {
        type: Number,
        required: true,
    },
    studentName: {
        type: String,
        required: true,
    },
    status: {
        type: String,
        enum: ['true', 'false'],
        required: true,
    },
    examDetail: {
        type: Object
    },
    exam: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Exam',
    },
    lecturer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

module.exports = mongoose.model("OpenExamAnswer", openExamAnswerSchema);
//why always wrong answer