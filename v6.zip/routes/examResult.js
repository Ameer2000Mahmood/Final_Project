const express = require('express');
const verifyToken = require('../utils/verifyToken');
const moment = require('moment');
const ExamResult = require('../models/ExamResult');
const User = require('../models/User');
const router = express.Router();

router.get('/exam-result', verifyToken(['student']), async (req, res) => {
    const cuser = await User.findById(req.user._id);
    const results = await ExamResult.find({ studentId: cuser.id });
    res.render('examResult', {
      status: '',
      results: results,
      moment: moment
    })
});

router.get('/exam-result-detail/:examId', verifyToken(['student']), async (req, res) => {
    const cuser = await User.findById(req.user._id);
    const result = await ExamResult.find({ studentId: cuser.id, examId: req.params.examId });
    res.render('examResultDetail', {
      status: '',
      result: result[0],
      moment: moment
    })
});

module.exports = router;