const express = require('express');
const verifyUser = require('../utils/verifyToken');
const Exam = require('../models/Exam');
const Question = require('../models/Question');
const Answer = require('../models/Answer');
const moment = require('moment');
const router = express.Router();

router.get('/closed-edit-exam/:examId', verifyUser(['lecturer']), async (req, res) => {
    const exam = await Exam.find({ examId: req.params.examId });
    const questionData = await Question.aggregate([
        {
            $match: { examId: exam[0]._id }
        },
        {
            $lookup: {
                from: 'answers',
                localField: '_id',
                foreignField: 'questionId',
                as: 'answers',
            }
        }
    ]);
    const examData = {
        examName: exam[0].examName,
        examDate: moment(exam[0].examDate).format("YYYY-MM-DD"),
        startHour: exam[0].startHour,
        totalTime: exam[0].totalTime,
        randomSort: exam[0].randomSort
    }

    const questions = [];
    for (let question of questionData) {
        questions.push({
            questionId: question._id,
            flag: question.flag,
            questionName: question.questionName,
            answer1Id: question.answers[0]._id,
            answer1: question.answers[0].answer,
            answerSymbol1: question.answers[0].answerSymbol,
            answer2Id: question.answers[1]._id,
            answer2: question.answers[1].answer,
            answerSymbol2: question.answers[1].answerSymbol,
            answer3Id: question.answers[2]._id,
            answer3: question.answers[2].answer,
            answerSymbol3: question.answers[2].answerSymbol,
            answer4Id: question.answers[3]._id,
            answer4: question.answers[3].answer,
            answerSymbol4: question.answers[3].answerSymbol,
            correctAnswerId: question.answers[4]._id,
            correctAnswer: question.answers[4].answer,
            answerSymbol5: question.answers[4].answerSymbol,
        });
    }
    examData.questions = questions;

    return res.render('closededitExam', {
      status: '',
      examData: examData,
      examId: req.params.examId
    });
});

router.get('/open-edit-exam/:examId', verifyUser(['lecturer']), async (req, res) => {
    const exam = await Exam.find({ examId: req.params.examId });
    const questionData = await Question.aggregate([
        {
            $match: { examId: exam[0]._id }
        },
    ]);
    const examData = {
        examName: exam[0].examName,
        examDate: moment(exam[0].examDate).format("YYYY-MM-DD"),
        startHour: exam[0].startHour,
        totalTime: exam[0].totalTime,
        randomSort: exam[0].randomSort
    }

    const questions = [];
    for (let question of questionData) {
        questions.push({
            questionId: question._id,
            flag: question.flag,
            questionName: question.questionName,
        });
    }
    examData.questions = questions;

    return res.render('openeditExam', {
      status: '',
      examData: examData,
      examId: req.params.examId
    });
});

router.post('/edit-exam/:examId', verifyUser(['lecturer']), async (req, res) => {
    try {
        const examData = {
            examName: req.body.examName,
            examDate: req.body.examDate,
            startHour: req.body.startHour,
            totalTime: req.body.totalTime,
            randomSort: req.body.randomSort,
        };
        let updateExam = await Exam.findOneAndUpdate(
            { examId: req.params.examId },
            examData,
            { upsert: true, new: true }
        );
        for (let question of req.body.questions) {
            let updateQuestion = await Question.findOneAndUpdate(
                { _id: question.questionId },
                { questionName: question.questionName, flag: question.flag },
                { upsert: true, new: true }
            );
            if (updateExam.type == "closed") {
                await Answer.findOneAndUpdate(
                    { _id: question.answer1Id },
                    { answer: question.answer1 },
                    { upsert: true, new: true }
                );
                await Answer.findOneAndUpdate(
                    { _id: question.answer2Id },
                    { answer: question.answer2 },
                    { upsert: true, new: true }
                );
                await Answer.findOneAndUpdate(
                    { _id: question.answer3Id },
                    { answer: question.answer3 },
                    { upsert: true, new: true }
                );
                await Answer.findOneAndUpdate(
                    { _id: question.answer4Id },
                    { answer: question.answer4 },
                    { upsert: true, new: true }
                );
                await Answer.findOneAndUpdate(
                    { _id: question.correctAnswerId },
                    { answer: question.correctAnswer, answerSymbol: question.correctAnswer },
                    { upsert: true, new: true }
                );
            }
        }

        return res.send({ status: "success", message: "The exam data updated successfully!" });
    } catch (error) {
        console.log(error)
        return res.send({ status: "error", message: "There is existed with same Exam ID" });
    }
});

module.exports = router;