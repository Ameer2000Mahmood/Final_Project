const mongoose = require("mongoose");
const AutoIncrement = require('mongoose-sequence')(mongoose);

const questionSchema = new mongoose.Schema({
    questionNumber: {
        type: Number,
    },
    flag: {
        type: Boolean,
        required: true,
    },
    questionName: {
        type: String,
        required: true,
    },
    examId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Exam',
    },
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

questionSchema.plugin(AutoIncrement, { inc_field: 'questionNumber', start_seq: 1000 });

module.exports = mongoose.model("Question", questionSchema);

//what the flag?