const mongoose = require("mongoose");
const AutoIncrement = require('mongoose-sequence')(mongoose);

const userSchema = new mongoose.Schema({
    id: {
        type: Number,
    },
    firstName: {
        type: String,
        required: true,
    },
    lastName: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
    },
    role: {
        type: String,
        enum: ['lecturer', 'student'],
        required: true,
    },
    password: {
        type: String,
        required: true,
    }
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

userSchema.plugin(AutoIncrement, { inc_field: 'id', start_seq: 111111111 });

// export model user with UserSchema
module.exports = mongoose.model("User", userSchema);
