// Import required dependencies and modules
const express = require('express');
const verifyUser = require('../utils/verifyToken');
const Exam = require('../models/Exam');
const Question = require('../models/Question');
const Answer = require('../models/Answer');

// Create a new instance of the express router
const router = express.Router();

// Handle HTTP GET requests for creating exams
router.get('/create-exam', verifyUser(['lecturer']), async (req, res) => {
    // Render the createExam view with an empty status object
    return res.render('createExam', {
      status: ''
    })
});

// Handle HTTP POST requests for creating exams
router.post('/create-exam', verifyUser(['lecturer']), async (req, res) => {
    // Extract the exam data from the request body
    const examData = {
        examName: req.body.examName,
        examDate: req.body.examDate,
        startHour: req.body.startHour,
        totalTime: req.body.totalTime,
        randomSort: req.body.randomSort,
        lecturer: req.user._id,
        type: 'closed',
    }

    try {
        // Create a new exam with the extracted exam data
        const exam = await Exam.create(examData);

        // Iterate over the questions in the request body
        for (let questionData of req.body.questions) {
            // Create a new question for the current question data and link it to the exam
            let question = await Question.create({ questionName: questionData.questionName, flag: questionData.flag, examId: exam._id });

            // Create new answers for the current question data
            // Each answer is linked to the question and has an answer symbol, an answer text and a status (true/false) indicating whether it is the correct answer
            await Answer.create({ answer: questionData.answer1, answerSymbol: 'A', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer2, answerSymbol: 'B', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer3, answerSymbol: 'C', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer4, answerSymbol: 'D', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.correctAnswer, answerSymbol: questionData.correctAnswer, status: 'true', questionId: question._id});
        }
        // Send a success response to the client
        return res.send({ status: "success", message: "The exam data created successfully!" });
    } catch (error) {
        // Log the error to the console and send an error response to the client
        return res.send({ status: "error", message: "There is existed with same Exam ID" });
    }
});

router.get('/open-create-exam', verifyUser(['lecturer']), async (req, res) => {
    return res.render('createOpenExam', {
      status: ''
    })
});

router.post('/open-create-exam', verifyUser(['lecturer']), async (req, res) => {
    const examData = {
        examName: req.body.examName,
        examDate: req.body.examDate,
        startHour: req.body.startHour,
        totalTime: req.body.totalTime,
        randomSort: req.body.randomSort,
        lecturer: req.user._id,
        type: 'open',
    }

    try {
        // Create a new exam with the extracted exam data
        const exam = await Exam.create(examData);

        // Iterate over the questions in the request body
        for (let questionData of req.body.questions) {
            // Create a new question for the current question data and link it to the exam
            await Question.create({ questionName: questionData.questionName, flag: questionData.flag, examId: exam._id });
        }
        // Send a success response to the client
        return res.send({ status: "success", message: "The exam data created successfully!" });
    } catch (error) {
        // Log the error to the console and send an error response to the client
        console.log(error)
        return res.send({ status: "error", message: "There is existed with same Exam ID" });
    }
});

// Export the router module
module.exports = router;
