const mongoose = require("mongoose");
const User = require("../models/User");
//המספקת פונקציות לגיבוב JAVASCRIPTספריית 
//  ואחסון מסד נתוניםbcrypt והשוואה של סיסמאות באמצעות אלגוריתם 
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");//load and access environment variables defined in the .env file
dotenv.config();

const saltLength = 10;
// Mongo DB conncetion
const dbConnection = process.env.MONGO_URL;
mongoose.set('strictQuery', false);
mongoose.connect(dbConnection, { useUnifiedTopology: true, useNewUrlParser: true })
    .then(() => console.log('MONGO CONNECTION OPEN!!'))
    .catch(err => console.log(err));
    
//Seed User For admin
const seedDB = async () => {
    const salt = await bcrypt.genSalt(saltLength);
    //hash the password
    const password = await bcrypt.hash("test!@#", salt)
    const seedUser = {
        firstName: "test",
        lastName: "test",
        email: "test@test.com",
        role: "lecturer",
        password: password
    };
    await User.deleteMany({});
    await User.create(seedUser);
}

seedDB().then(() => {
    mongoose.connection.close();
})