const express = require('express');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const cors = require('cors');
var path = require('path');

const app = express();
const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

const PORT = process.env.PORT || 5000;

// Connect to DB
mongoose.set('strictQuery', false);
mongoose.connect(
    process.env.MONGO_URL,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    }
)
.then(() => console.log('💾 Connected to DB'))
.catch((err) => {
    console.error(err);
});

// Setting EJS as templating engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
// Middleware
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function (req, res) {
    res.redirect('/signin');
});
app.use(require('./routes/signin'));
app.use(require('./routes/signup'));
app.use(require('./routes/signout'));
app.use(require('./routes/dashboard'));
app.use(require('./routes/editExam'));
app.use(require('./routes/exam'));
app.use(require('./routes/examResult'));
app.use(require('./routes/statistics'));

app.listen(PORT, () => console.log(`🏎  API Server up and running at localhost:${process.env.PORT}`));