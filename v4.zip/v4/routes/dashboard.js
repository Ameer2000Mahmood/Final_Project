// Import required dependencies and modules
const express = require("express");
const Exam = require("../models/Exam");
const ExamResult = require("../models/ExamResult");
const User = require("../models/User");
const verifyUser = require("../utils/verifyToken");

// Create a new instance of the express router
const router = express.Router();

// Handle HTTP GET requests for the lecturer dashboard page
router.get("/lecturerDashboard", verifyUser(["lecturer"]), async (req, res) => {
  // Get the current user's details
  const cuser = await User.findById(req.user._id);

  // Count the total number of exams, the total number of exams the current user created, and the total number of students
  let allExams = await Exam.countDocuments();
  let allMyExams = await Exam.countDocuments({ lecturer: cuser._id });
  let allStudents = await User.countDocuments({ role: "student" });

  // Get the IDs of all exams created by the current user
  const examIds = await Exam.find({ lecturer: req.user._id }).select(["_id"]);
  let examIdData = examIds.map((examId) => {
    return examId._id;
  });

  // Get statistics for all exams created by the current user, including the total number of students who have taken each exam and the average grade for each exam
  const results = await ExamResult.aggregate([
    {
      $match: { exam: { $in: examIdData } },
    },
    {
      $sort: { examId: 1 },
    },
    {
      $group: {
        _id: { examId: "$examId" },
        totalStudents: { $sum: 1 },
        avgGrade: { $avg: "$grade" },
      },
    },
  ]);

  // Prepare the statistics data for the view
  let statistics = {};
  let examData = [];
  let totalStudentData = [];
  let avgGradeData = [];
  for (let result of results) {
    examData.push("Exam ID:" + result._id.examId);
    totalStudentData.push(result.totalStudents);
    avgGradeData.push(result.avgGrade);
  }
  statistics.examData = examData;
  statistics.totalStudentData = totalStudentData;
  statistics.avgGradeData = avgGradeData;

  // Render the lecturerDashboard view with the relevant data
  return res.render("lecturerDashboard", {
    status: "",
    allExams: allExams,
    allMyExams: allMyExams,
    allStudents: allStudents,
    statistics: statistics,
  });
});

// Handle HTTP GET requests for the student dashboard page
router.get("/studentDashboard", verifyUser(["student"]), async (req, res) => {
  // Get the current user's details
  const cuser = await User.findById(req.user._id);

  // Count the total number of exams and the number of exams passed by the current user
  let allExams = await Exam.countDocuments();
  let passExams = await ExamResult.countDocuments({ studentId: cuser.id });

  // Get statistics for all exams taken by the current user, including the average grade, number of wrong answers, and number of correct answers for each exam
  const results = await ExamResult.aggregate([
    {
      $match: { studentId: cuser.id },
    },
    {
      $sort: { examId: 1 },
    },
    {
      $group: {
        _id: { examId: "$examId" },
        avgGrade: { $avg: "$grade" },
        wrongAnswers: { $sum: "$wrongAnswers" },
        correctAnswers: { $sum: "$correctAnswers" },
      },
    },
  ]);

  // Prepare the statistics data for the view
  let statistics = {};
  let examData = [];
  let gradeData = [];
  let wrongAnswersData = [];
  let correctAnswersData = [];
  for (let result of results) {
    examData.push("Exam ID:" + result._id.examId);
    correctAnswersData.push(result.correctAnswers);
    wrongAnswersData.push(result.wrongAnswers);
    gradeData.push(result.avgGrade);
  }
  statistics.examData = examData;
  statistics.correctAnswersData = correctAnswersData;
  statistics.wrongAnswersData = wrongAnswersData;
  statistics.gradeData = gradeData;

  // Render the studentDashboard view with the relevant data
  return res.render("studentDashboard", {
    status: "",
    allExams: allExams,
    passExams: passExams,
    statistics: statistics,
  });
});

// Export the router module
module.exports = router;
