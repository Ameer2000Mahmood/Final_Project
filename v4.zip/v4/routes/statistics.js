const express = require('express');
const verifyToken = require('../utils/verifyToken');
const moment = require('moment');
const ExamResult = require('../models/ExamResult');
const User = require('../models/User');
const Exam = require('../models/Exam');
const router = express.Router();

router.get('/lecturer-statistics', verifyToken(['lecturer']), async (req, res) => {
    const examIds = await Exam.find({ lecturer: req.user._id }).select(['_id']);
    let examIdData = examIds.map(examId => {
        return examId._id;
    });

    const results = await ExamResult.aggregate([
        {
            $match: { exam: { $in: examIdData } },
        },
        { 
            $sort: { examId: 1}
        },
        {
            $group: {
                _id: { examId: "$examId" },
                totalStudents: { $sum: 1 },
                avgGrade: { $avg: "$grade" }
            }
        }
    ]);
    let statistics = {};
    let examData = [];
    let totalStudentData = [];
    let avgGradeData = [];
    for (let result of results) {
        examData.push("Exam ID:" + result._id.examId);
        totalStudentData.push(result.totalStudents);
        avgGradeData.push(result.avgGrade);
    }
    statistics.examData = examData;
    statistics.totalStudentData = totalStudentData;
    statistics.avgGradeData = avgGradeData;

    const resultPerStuents = await ExamResult.aggregate([
        {
            $match: { exam: { $in: examIdData } },
        },
        { 
            $sort: { studentId: 1}
        },
        {
            $group: {
                _id: { 
                    studentId: "$studentId" 
                },
                totalExams: { $sum: 1 },
                totalWrongAnswers: { $sum: "$wrongAnswers" },
                totalCorrectAnswers: { $sum: "$correctAnswers" },
                avgGrade: { $avg: "$grade" }
            }
        }
    ]);
    let studentstatistics = {};
    let studentexamData = [];
    let totalWrongAnswerData = [];
    let totalCorrectAnswerData = [];
    let studenttotalExamData = [];
    let studentavgGradeData = [];
    for (let resultPer of resultPerStuents) {
        studentexamData.push("Student ID:" + resultPer._id.studentId);
        studenttotalExamData.push(resultPer.totalExams);
        studentavgGradeData.push(resultPer.avgGrade);
        totalCorrectAnswerData.push(resultPer.totalCorrectAnswers);
        totalWrongAnswerData.push(resultPer.totalWrongAnswers);
    }
    studentstatistics.studentexamData = studentexamData;
    studentstatistics.studenttotalExamData = studenttotalExamData;
    studentstatistics.studentavgGradeData = studentavgGradeData;
    studentstatistics.totalCorrectAnswerData = totalCorrectAnswerData;
    studentstatistics.totalWrongAnswerData = totalWrongAnswerData;
    res.render('lecturerStatistics', {
      status: '',
      statistics: statistics,
      studentstatistics: studentstatistics,
      moment: moment
    })
});

router.get('/exam-result/:examId', verifyToken(['student']), async (req, res) => {
    const cuser = await User.findById(req.user._id);
    const result = await ExamResult.find({ studentId: cuser.id, examId: req.params.examId });
    res.render('examResult', {
      status: '',
      result: result[0],
      moment: moment
    })
});

module.exports = router;