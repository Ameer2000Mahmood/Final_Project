const mongoose = require("mongoose");
const AutoIncrement = require('mongoose-sequence')(mongoose);

const examSchema = new mongoose.Schema({
    examId: {
        type: Number,
    },
    examName: {
        type: String,
        required: true,
    },
    examDate: {
        type: Date,
        required: true,
    },
    lecturer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    startHour: {
        type: String,
        required: true,
    },
    totalTime: {
        type: Number,
        required: true,
    },
    randomSort: {
        type: String,
        enum: ['true', 'false'],
        required: true,
    },
    type: {
        type: String,
        enum: ['closed', 'open'],
        required: true,
    }
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

examSchema.plugin(AutoIncrement, { inc_field: 'examId', start_seq: 1000 });

module.exports = mongoose.model("Exam", examSchema);
