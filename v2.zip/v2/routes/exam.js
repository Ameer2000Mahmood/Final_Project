const express = require('express');
const Exam = require('../models/Exam');
const verifyToken = require('../utils/verifyToken');
const moment = require('moment');
const Question = require('../models/Question');
const Answer = require('../models/Answer');
const User = require('../models/User');
const ExamResult = require('../models/ExamResult');
const router = express.Router();

router.get('/lecturer-exams', verifyToken(['lecturer']), async (req, res) => {
  
  const exams = await Exam.find({ lecturer: req.user._id });
  res.render('lecturerExam', {
    status: '',
    exams: exams,
    moment: moment
  })
});

router.get('/student-exams', verifyToken(['student']), async (req, res) => {
  const cuser = await User.findById(req.user._id);
  const examIds = await ExamResult.find({ studentId: cuser.id }).select('exam');
  let examIdData = examIds.map(examId => {
    return examId.exam;
  });
  console.log(examIdData, examIds)
  const exams = await Exam.aggregate([
    {
        $match: { _id: { $nin: examIdData } },
    },
    { 
        $sort: { examId: -1 }
    },
  ]);

  res.render('studentExams', {
    status: '',
    exams: exams,
    moment: moment
  })
});

router.get('/student-exam-page/:examId', verifyToken(['student']), async (req, res) => {
  const exam = await Exam.find({ examId: req.params.examId });
  const questionLength = await Question.countDocuments({ examId: exam[0]._id });
  let questions;
  if (exam[0].randomSort == "true") {
    questions = await Question.aggregate([{ $match: { examId: exam[0]._id } }, { $sample: { size: questionLength } }]);
  } else {
    questions = await Question.aggregate([{ $match: { examId: exam[0]._id } }]);
  }

  let questionData = [];
  for (let question of questions) {
    let tempQuestion = {};
    let answers;
    if (exam[0].randomSort == "true") {
      answers = await Answer.aggregate([{ $match: { questionId: question._id, status: "false" } }, { $sample: { size: 4 } }])
    } else {
      answers = await Answer.aggregate([{ $match: { questionId: question._id, status: "false" } }])
    }

    tempQuestion.questionName = question.questionName;
    tempQuestion.answers = answers;

    questionData.push(tempQuestion);
  }
  res.render('examPage', {
    status: '',
    questionData: questionData,
    examId: req.params.examId,
    examTotalTime: exam[0].totalTime
  })
});

router.post('/student-exam-page/:examId', verifyToken(['student']), async (req, res) => {
  const examData = req.body.data;
  const student = await User.findById(req.user._id).select('-__v -password');
  const exam = await Exam.find({ examId: req.params.examId });
  let grade = 0;
  let wrongAnswers = 0;
  let correctAnswers = 0;
  let questions = await Question.find({ examId: exam[0]._id }).populate({
    path: 'examId',
    select: {
      _id: 1, examId: 1, examName: 1,
    },
  }).select('-__v');
  let examResult = {};
  examResult.studentId = student.id;
  examResult.studentName = student.firstName + " " + student.lastName;
  examResult.examId = exam[0].examId;
  examResult.exam = exam[0]._id;
  let examDetail = [];
  for (let question of questions) {
    let temp = {};
    let found = examData.some(el => el.questionId === question._id.valueOf());
    if (found) {
      let answer = await Answer.find({ questionId: question._id, status: 'true' });
      let answerD = examData.filter((el) => el.questionId === question._id.valueOf());
      if (answer[0].answerSymbol == answerD[0].answer) {
        temp.questionName = question.questionName;
        temp.wrongAnswer = '';
        temp.correctAnswer = answer[0].answerSymbol;
        temp.status = true;
      } else {
        temp.questionName = question.questionName;
        temp.wrongAnswer = answerD[0].answer;
        temp.correctAnswer = answer[0].answerSymbol;
        temp.status = false;
      }
    } else {
      temp.questionName = question.questionName;
      temp.wrongAnswer = 'not submitted';
      temp.correctAnswer = '';
      temp.status = false;
    }
    examDetail.push(temp);
  }

  for (let detail of examDetail) {
    if (detail.status) {
      grade = grade + 1;
      correctAnswers = correctAnswers + 1;
    }
  }
  examResult.grade = (grade / examDetail.length).toFixed(2);
  examResult.examDetail = examDetail;
  examResult.correctAnswers = correctAnswers;
  examResult.wrongAnswers = examDetail.length - correctAnswers;
  try {
    await ExamResult.create(examResult);
  } catch (error) {
    return res.send({ status: "error", message: "Error found!" })
  }
  return res.send({ status: "success", message: "You have submitted the exam!" })
});

router.post('/check-exam', verifyToken(['student']), async (req, res) => {
  const cuser = await User.findById(req.user._id);
  const examResult = await ExamResult.find({ studentId: cuser.id, examId: req.body.examId });
  if (examResult.length > 0) {
    return res.send({ status: "error", message: "You have already attempted this exam." })
  } else {
    const exam = await Exam.find({ examId: req.body.examId });
    const totalTime = exam[0].totalTime;
    let estimateExamTime = moment(moment(exam[0].examDate).format("YYYY-MM-DD") + ' ' + exam[0].startHour, 'YYYY-MM-DD HH:mm').add(totalTime, 'hours');
    console.log()
    if (estimateExamTime < moment()) {
      return res.send({ status: "error", message: "The exam time was passed." })
    }
    return res.send({ status: "success", message: "" })
  }

});

module.exports = router;