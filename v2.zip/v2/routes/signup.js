const express = require('express');
const User = require('../models/User');
const bcrypt = require('bcrypt');
const router = express.Router();

const saltLength = 10;

router.get('/signup', async (req, res) => {
    return res.render('signup', {
        status: ''
    })
});

router.post('/signup', async (req, res) => {
 
    // check for unique user
    const emailExists = await User.findOne({ email: req.body.email });
    if (emailExists) { return res.render("signup", { status: "error", message: "Email already exists" }); }
    
    // hash the password
    const salt = await bcrypt.genSalt(saltLength);
    const hashPassword = await bcrypt.hash(req.body.password, salt);
    
    const userData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: hashPassword,
        role: req.body.role,
    }
    try {
        await User.create(userData);
    } catch (err) {
        console.log(err)
    }
    return res.render("signin", { status: "success", message: "User successfully registered" })
});

module.exports = router;