// sidebarCompact();

// console.log('test4')
"use strict";