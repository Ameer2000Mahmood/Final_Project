const mongoose = require("mongoose");
const User = require("../models/User");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
dotenv.config();

const saltLength = 10;
// Mongo DB conncetion
const dbConnection = process.env.MONGO_URL;
mongoose.set('strictQuery', false);
mongoose.connect(dbConnection, { useUnifiedTopology: true, useNewUrlParser: true })
    .then(() => console.log('MONGO CONNECTION OPEN!!'))
    .catch(err => console.log(err));
    
//Seed User For admin
const seedDB = async () => {
    const salt = await bcrypt.genSalt(saltLength);
    const password = await bcrypt.hash("lecturer!@#", salt)
    const seedUser = {
        firstName: "admin",
        lastName: "admin",
        email: "admin@admin.com",
        role: "lecturer",
        password: password
    };
    await User.deleteMany({});
    await User.create(seedUser);
}

seedDB().then(() => {
    mongoose.connection.close();
})