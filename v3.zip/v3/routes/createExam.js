const express = require('express');
const verifyUser = require('../utils/verifyToken');
const Exam = require('../models/Exam');
const Question = require('../models/Question');
const Answer = require('../models/Answer');
const router = express.Router();

router.get('/create-exam', verifyUser(['lecturer']), async (req, res) => {
    return res.render('createExam', {
      status: ''
    })
});

router.post('/create-exam', verifyUser(['lecturer']), async (req, res) => {
    const examData = {
        examName: req.body.examName,
        examDate: req.body.examDate,
        startHour: req.body.startHour,
        totalTime: req.body.totalTime,
        randomSort: req.body.randomSort,
        lecturer: req.user._id,
    }

    try {
        const exam = await Exam.create(examData);
        for (let questionData of req.body.questions) {
            let question = await Question.create({ questionName: questionData.questionName, flag: questionData.flag, examId: exam._id });
            await Answer.create({ answer: questionData.answer1, answerSymbol: 'A', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer2, answerSymbol: 'B', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer3, answerSymbol: 'C', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.answer4, answerSymbol: 'D', status: 'false', questionId: question._id});
            await Answer.create({ answer: questionData.correctAnswer, answerSymbol: questionData.correctAnswer, status: 'true', questionId: question._id});
        }
        return res.send({ status: "success", message: "The exam data created successfully!" });
    } catch (error) {
        console.log(error)
        return res.send({ status: "error", message: "There is existed with same Exam ID" });
    }
    
});

module.exports = router;