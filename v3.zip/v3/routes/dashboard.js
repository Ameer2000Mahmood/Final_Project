const express = require('express');
const Exam = require('../models/Exam');
const ExamResult = require('../models/ExamResult');
const User = require('../models/User');
const verifyUser = require('../utils/verifyToken');
const router = express.Router();

router.get('/lecturerDashboard', verifyUser(['lecturer']), async (req, res) => {
  const cuser = await User.findById(req.user._id);
  let allExams = await Exam.countDocuments();
  let allMyExams = await Exam.countDocuments({ lecturer: cuser._id });
  let allStudents = await User.countDocuments({ role: 'student' });

  const examIds = await Exam.find({ lecturer: req.user._id }).select(['_id']);
  let examIdData = examIds.map(examId => {
    return examId._id;
  });

  const results = await ExamResult.aggregate([
    {
      $match: { exam: { $in: examIdData } },
    },
    {
      $sort: { examId: 1 }
    },
    {
      $group: {
        _id: { examId: "$examId" },
        totalStudents: { $sum: 1 },
        avgGrade: { $avg: "$grade" }
      }
    }
  ]);
  let statistics = {};
  let examData = [];
  let totalStudentData = [];
  let avgGradeData = [];
  for (let result of results) {
    examData.push("Exam ID:" + result._id.examId);
    totalStudentData.push(result.totalStudents);
    avgGradeData.push(result.avgGrade);
  }
  statistics.examData = examData;
  statistics.totalStudentData = totalStudentData;
  statistics.avgGradeData = avgGradeData;
  return res.render('lecturerDashboard', {
    status: '',
    allExams: allExams,
    allMyExams: allMyExams,
    allStudents: allStudents,
    statistics: statistics
  })
});

router.get('/studentDashboard', verifyUser(['student']), async (req, res) => {
  const cuser = await User.findById(req.user._id);
  let allExams = await Exam.countDocuments();
  let passExams = await ExamResult.countDocuments({ studentId: cuser.id });

  const results = await ExamResult.aggregate([
    {
      $match: { studentId: cuser.id },
    },
    {
      $sort: { examId: 1 }
    },
    {
      $group: {
        _id: { examId: "$examId" },
        avgGrade: { $avg: "$grade" },
        wrongAnswers: { $sum: "$wrongAnswers" },
        correctAnswers: { $sum: "$correctAnswers" },
      }
    }
  ]);

  let statistics = {};
  let examData = [];
  let gradeData = [];
  let wrongAnswersData = [];
  let correctAnswersData = [];
  for (let result of results) {
      examData.push("Exam ID:" + result._id.examId);
      correctAnswersData.push(result.correctAnswers);
      wrongAnswersData.push(result.wrongAnswers);
      gradeData.push(result.avgGrade);
  }
  statistics.examData = examData;
  statistics.correctAnswersData = correctAnswersData;
  statistics.wrongAnswersData = wrongAnswersData;
  statistics.gradeData = gradeData;
  return res.render('studentDashboard', {
    status: '',
    allExams: allExams,
    passExams: passExams,
    statistics: statistics
  })
});

module.exports = router;