const mongoose = require("mongoose");

const examResultSchema = new mongoose.Schema({
    studentId: {
        type: Number,
        required: true,
    },
    studentName: {
        type: String,
        required: true,
    },
    examId: {
        type: Number,
        required: true,
    },
    grade: {
        type: Number,
        required: true,
    },
    correctAnswers: {
        type: Number,
        required: true,
    },
    wrongAnswers: {
        type: Number,
        required: true,
    },
    examDetail: {
        type: Object
    },
    exam: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Exam',
    },
}, {
    timestamps: {
        createdAt: 'createdAt',
        updatedAt: 'updatedAt',
    },
});

module.exports = mongoose.model("ExamResult", examResultSchema);
