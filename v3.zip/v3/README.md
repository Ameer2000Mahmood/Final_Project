# Exam Management Application

1. npm install

# (Optional)
    For seed user data, please try following command.
    `node config/seed.js`

2. npm run start